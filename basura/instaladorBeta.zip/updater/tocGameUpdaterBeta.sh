killall tocGame
mkdir /home/hit/tocGameTemporalDownload
echo Pepito por aqui
git clone --depth 1 https://github.com/dobleamarilla/tocGameV2.git /home/hit/tocGameTemporalDownload/
npm install --prefix /home/hit/tocGameTemporalDownload/
npm run reparar --prefix  /home/hit/tocGameTemporalDownload/
echo sa | sudo -S npm run build:linux --prefix  /home/hit/tocGameTemporalDownload/
echo sa | sudo -S mv /home/hit/tocGameTemporalDownload/linuxBuild/tocGame-linux-x64 /home/hit/tocGameFunciona/
echo sa | sudo -S chown -R hit:hit /home/hit/tocGameFunciona/
mv /home/hit/tocGame /home/hit/tocGameScripts
mv /home/hit/tocGameFunciona /home/hit/tocGame
echo sa | sudo -S cp -f -r /home/hit/tocGameScripts/tocGame/scripts /home/hit/tocGame/scripts 
echo sa | sudo -S chown -R hit:hit /home/hit/tocGame/
killall tocGame
rm -rf /home/hit/tocGameTemporalDownload
echo sa | sudo -S chown -R hit:hit /home/hit/
echo sa | sudo -S chmod 755 /home/hit/