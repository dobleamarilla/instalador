#!/bin/sh
~/clearOne/CoLinux -p ~/clearOne