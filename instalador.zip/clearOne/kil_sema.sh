ipcs -s

ipcrm -S 0x3b9ac9ff
ipcrm -S 0x00004267
ipcrm -S 0x0000270f 

ipcs -s