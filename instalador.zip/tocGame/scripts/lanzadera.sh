#!/bin/sh

while true; do
	~/tocGame/scripts/starttoc.sh
	sleep 60       # check cada 60 segundos
done