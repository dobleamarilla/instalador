sudo chmod 777 -R /dev/bus/usb/
sudo chmod 777 -R /dev/ttyS0
sudo chmod 777 -R /dev/ttyS1
